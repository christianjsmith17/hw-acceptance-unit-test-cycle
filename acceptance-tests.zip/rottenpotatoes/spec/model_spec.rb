require 'rails_helper'

describe Movie do
    describe 'movie with a director' do
        it 'should receive the director of the movie' do
            
        end
    end
end